#include <16F1827.h>
#device ADC=16

#FUSES NOWDT                    //No Watch Dog Timer
#FUSES NOMCLR                   //Master Clear pin used for I/O
#FUSES NOBROWNOUT               //No brownout reset
#FUSES NOLVP                    //No low voltage prgming, B3(PIC16) or B5(PIC18) used for I/O

#use delay(clock=4000000,crystal=4MHz)
#use rs232(baud=2400,parity=N,xmit=PIN_B2,rcv=PIN_B1,bits=8,stream=PORT1)

